#ifndef BasicBuffer_HH
#define BasicBuffer_HH
#include <click/element.hh>
#include <click/timer.hh>
#include "packet.hh"

#define MAX_PACKET_NUM 20

CLICK_DECLS

class BasicBuffer : public Element {
public:
    BasicBuffer();
    ~BasicBuffer();
    const char *class_name() const { return "BasicBuffer";}
    const char *port_count() const { return "2/2";}
    const char *processing() const { return PUSH; }
    
    void push(int port, Packet *packet);
    int initialize(ErrorHandler*);

private:
    char _sender_buffer[MAX_PACKET_NUM * sizeof(struct TCP_Packet)];
    char _receiver_buffer[MAX_PACKET_NUM * sizeof(struct TCP_Packet)];
    uint8_t _sender_start_pos;
    uint8_t _sender_end_pos;
    uint8_t _receiver_start_pos;
    uint8_t _receiver_end_pos;
    
    WritablePacket* BasicBuffer::CreateInfoPacket();
    uint8_t calculate_buffer_size(uint8_t s, uint8_t e);
};

CLICK_ENDDECLS
#endif

