/*
 1）是不是考虑发一些包回去给tcp，告知还有多少空位
 INFO PACKET?
 2）初始化！
 */

#include <click/config.h>
#include <click/confparse.hh>
#include <click/error.hh>
#include <click/timer.hh>
#include <click/packet.hh>
#include "BasicBuffer.hh"
#include "packets.hh"
#include "packet.hh"

CLICK_DECLS

BasicBuffer::BasicBuffer() {
    click_chatter("Creating a BasicBuffer object.");
}

BasicBuffer::~BasicBuffer(){
    click_chatter("Killing a BasicBuffer object.");
}

int BasicBuffer::initialize(ErrorHandler *errh){
    return 0;
}

void BasicBuffer::push(int port, Packet *income_packet) {
    assert(income_packet);
    struct TCP_Packet *packet = (struct TCP_Packet *)income_packet->data();
    struct TCP_Header header = (struct TCP_Header)packet->header;
    output(0).push(income_packet);
    if(port == 0){  // from TCP, use sender buffer
        // Store in buffer
        int TCP_Packet_size = sizeof(struct TCP_Packet);
        memcpy((void *)(_senderbuffer + _sender_end_pos * TCP_Packet_size), (const void *)income_packet, TCP_Packet_size);
        _sender_end_pos = (_sender_end_pos + 1) % MAX_PACKET_NUM;
        
        // Route
        output(1).push(income_packet);
        output(0).push(CreateInfoPacket());  // back to TCP
    }
    else if(port == 1){  //  from IP, use receiver buffer
        // 这里可能会接收到ack！往ack里面写东西！data那里都是空的啊朋友！
    }
}

WritablePacket* BasicBuffer::CreateInfoPacket(){
    WritablePacket *packet = Packet::make(0, 0, sizeof(struct TCP_Header), 0);
    struct TCP_Packet* packet_ptr = (struct TCP_Packet*)packet->data();
    struct TCP_Header* header_ptr = (struct TCP_Header*)(&(packet_ptr->header));
    
    memset(packet_ptr, 0, packet->length());
    
    // Write TCP_Header
    header_ptr->type = INFO;
    header_ptr->empty_buffer_size = calculate_buffer_size(_sender_start_pos, _sender_end_pos);
    
    return packet;
}

uint8_t BasicBuffer::calculate_buffer_size(uint8_t s, uint8_t e){
    if(e >= s){
        return MAX_PACKET_NUM - 1 - (e - s);
    }
    return s - e - 1;
}

CLICK_ENDDECLS
EXPORT_ELEMENT(BasicBuffer)

