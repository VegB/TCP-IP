//
//  packets.h
//  TCP-IP
//
//  Created by 朱芄蓉 on 13/11/2017.
//  Copyright © 2017 朱芄蓉. All rights reserved.
//

#ifndef packets_h
#define packets_h

typedef enum {
    DATA = 0,
    HELLO,
    ACK,
    SYN,
    SYNACK,
    FIN
} packet_types;

struct IP_Header{
    uint8_t type;
    uint8_t sequence;
    uint8_t source;
    uint8_t destination;
    uint32_t size;
};

struct TCP_Header{
    unit32_t offset;
    unit32_t size;
    unit8_t more_packets;
};

#endif /* packets_h */
