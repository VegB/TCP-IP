//
//  router.cpp
//  TCP-IP
//
//  Created by 朱芄蓉 on 13/11/2017.
//  Copyright © 2017 朱芄蓉. All rights reserved.
//

#include <click/config.h>
#include <click/confparse.hh>
#include <click/error.hh>
#include <click/timer.hh>
#include <click/packet.hh>
#include "router.hpp"
#include "packets.hh"

CLICK_DECLS

Router::Router() {
}

Router::~Router(){
    
}

int Router::initialize(ErrorHandler *errh){
    return 0;
}

void Router::push(int port, Packet *packet) {
    assert(packet);
    struct PacketHeader *header = (struct PacketHeader *)packet->data();
    if(header->type == DATA || header->type == ACK) {
        click_chatter("Received Data from %u with destination %u", header->source, header->destination);
        int next_port = _ports_table.get(header->destination);
        output(next_port).push(packet);
    } else if(header->type == HELLO) {
        click_chatter("Received Hello from %u on port %d", header->source, port);
        _ports_table.set(header->source, port);
    } else {
        click_chatter("Wrong packet type");
        packet->kill();
    }
}

CLICK_ENDDECLS
EXPORT_ELEMENT(Router)

