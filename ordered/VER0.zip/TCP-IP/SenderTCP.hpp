//
//  SenderTCP.hpp
//  TCP-IP
//
//  Created by 朱芄蓉 on 13/11/2017.
//  Copyright © 2017 朱芄蓉. All rights reserved.
//

#ifndef SENDERTCP_HH
#define SENDERTCP_HH
#include <click/element.hh>
#include <click/timer.hh>

CLICK_DECLS

class SenderTCP : public Element {
public:
    SenderTCP();
    ~SenderTCP();
    const char *class_name() const { return "BasicClient";}
    const char *port_count() const { return "2/1";}
    const char *processing() const { return PUSH; }
    int configure(Vector<String> &conf, ErrorHandler *errh);
    
    void run_timer(Timer*);
    void push(int port, Packet *packet);
    int initialize(ErrorHandler*);
    
private:
    Timer _timerHello;
    Timer _timerTO;
    uint32_t _seq;
    uint32_t _delay;
    uint32_t _period;
    uint32_t _periodHello;
    uint32_t _time_out;
    uint32_t _my_address;
    uint32_t _other_address;
    int transmissions;
};

CLICK_ENDDECLS
#endif

