//
//  SenderIP.cpp
//  TCP-IP
//
//  Created by 朱芄蓉 on 13/11/2017.
//  Copyright © 2017 朱芄蓉. All rights reserved.
//

#include "SenderIP.hpp"
#include <click/config.h>
#include <click/confparse.hh>
#include <click/error.hh>
#include <click/timer.hh>
#include <click/packet.hh>
#include "packets.h"

CLICK_DECLS

SenderIP::SenderIP() {
}

SenderIP::~SenderIP(){
    
}

int SenderIP::initialize(ErrorHandler *errh){
    return 0;
}

void SenderIP::push(int port, Packet *packet) {
    assert(packet);
    struct IP_Header *header = (struct IP_Header *)packet->data();
    if(header->type == 0) {
        output(0).push(packet);
    } else if(header->type == 1) {
        output(1).push(packet);
    } else if(header->type == 2) {
        output(2).push(packet);
    } else {
        click_chatter("Wrong packet type");
        packet->kill();
    }
}

CLICK_ENDDECLS
EXPORT_ELEMENT(SenderIP)
