//
//  router.hpp
//  TCP-IP
//
//  Created by 朱芄蓉 on 13/11/2017.
//  Copyright © 2017 朱芄蓉. All rights reserved.
//

#ifndef CLICK_ROUTER_HH
#define CLICK_ROUTER_HH
#include <click/element.hh>
#include <click/timer.hh>
#include <click/hashtable.hh>

CLICK_DECLS

class Router : public Element {
public:
    Router();
    ~Router();
    const char *class_name() const { return "Router";}
    const char *port_count() const { return "1-/1-";}
    const char *processing() const { return PUSH; }
    
    void push(int port, Packet *packet);
    int initialize(ErrorHandler*);
    
private:
    HashTable<int, int> _ports_table;
    
};

CLICK_ENDDECLS
#endif

