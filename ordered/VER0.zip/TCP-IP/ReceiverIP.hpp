//
//  ReceiverIP.hpp
//  TCP-IP
//
//  Created by 朱芄蓉 on 13/11/2017.
//  Copyright © 2017 朱芄蓉. All rights reserved.
//

#ifndef CLICK_RECEIVERIP_HH
#define CLICK_RECEIVERIP_HH
#include <click/element.hh>
#include <click/timer.hh>

CLICK_DECLS

class ReceiverIP : public Element {
public:
    BasicClassifier();
    ~BasicClassifier();
    const char *class_name() const { return "ReceiverIP";}
    const char *port_count() const { return "1/3";}
    const char *processing() const { return PUSH; }
    
    void push(int port, Packet *packet);
    int initialize(ErrorHandler*);
    
};

CLICK_ENDDECLS
#endif


