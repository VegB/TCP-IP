cp ~/click/elements/local/receiverbuffer* ./
cp ~/click/elements/local/receivertcp* ./
cp ~/click/elements/local/sendertcp* ./
cp ~/click/elements/local/senderbuffer*  ./
cp ~/click/elements/local/packet.hh ./
cp ~/click/elements/local/basicip* ./
cp ~/click/elements/local/basicrouter* ./
