cp receiverbuffer* ~/click/elements/local/
cp receivertcp* ~/click/elements/local/
cp sendertcp* ~/click/elements/local/
cp senderbuffer* ~/click/elements/local
cp packet.hh ~/click/elements/local/
cp basicip* ~/click/elements/local/
cp basicrouter* ~/click/elements/local/
